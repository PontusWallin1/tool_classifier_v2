# CoreMLDemo-YT
Core ML Demo source code for YT video.
